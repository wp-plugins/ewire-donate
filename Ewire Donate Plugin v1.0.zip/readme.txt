Ewire Donate Plugin
20-11-2009
For Wordress

Release notes: ewirepayment.codeplex.com

** Version 1.0B **

Create a donation in a few clicks and use the widgets!


Ewire can not be held responsible for any damages or errors caused by the package,
problem resolving goto: ewirepayment.codeplex.com.

Good luck,

Ewire

